-- MySQL dump 10.15  Distrib 10.0.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: cms
-- ------------------------------------------------------
-- Server version	10.0.34-MariaDB-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `cat_id` int(3) NOT NULL AUTO_INCREMENT,
  `cat_title` varchar(255) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'PHP'),(2,'Javascript'),(3,'MySQL'),(4,'Apache'),(7,'Test 1');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `comment_id` int(3) NOT NULL AUTO_INCREMENT,
  `comment_post_id` int(3) NOT NULL,
  `comment_author` varchar(255) NOT NULL,
  `comment_email` varchar(255) NOT NULL,
  `comment_content` text NOT NULL,
  `comment_status` varchar(255) NOT NULL,
  `comment_date` date NOT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,1,'Ralf Newman','ralf.newman@gmail.com','This is great post !!!','approved','2018-03-27'),(2,3,'Joe Black','rafalnowicki4@gmail.com','This is brillant post! Good Job!','approved','2018-03-31'),(3,3,'Cindy','cindy@cindy.com','Hey Rafal You rock!!! Are you marry?','approved','2018-04-13'),(4,3,'Christanema','jdkskshjs@cmkdscdskmcldsckds.com','Checking if sql query is working','approved','2018-04-17'),(5,1,'me','cindy@cindy.com','cdscdscdscdscsdcdsdsc','approved','2018-04-17'),(6,1,'Christanema','cindy@cindy.com','wrtyukmncsdrtyuknbvcxsertykbvcs','approved','2018-04-17'),(8,1,'Cindy','jdkskshjs@cmkdscdskmcldsckds.com','fsgtrytyukuicdscdscsdcs','approved','2018-04-17'),(9,7,'Wonderwoman','wonderwoman@marvel.com','dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw ','approved','2018-04-18'),(10,7,'Wonderwoman','wonderwoman@marvel.com','dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw dcdscdscdsdewrewrw ','approved','2018-04-18');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `post_id` int(3) NOT NULL AUTO_INCREMENT,
  `post_category_id` int(3) NOT NULL,
  `post_title` varchar(255) NOT NULL,
  `post_author` varchar(255) NOT NULL,
  `post_date` date NOT NULL,
  `post_image` text NOT NULL,
  `post_content` text NOT NULL,
  `post_tags` varchar(255) NOT NULL,
  `post_comment_count` int(11) NOT NULL DEFAULT '0',
  `post_status` varchar(255) NOT NULL DEFAULT 'draft',
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (3,1,'Secondary great post','Belinda','2018-04-24','troy4-900x300.jpg','Wooooooow, this is really cool post. Can you call me?','post',3,'published'),(5,1,'fdsfdsfds','','2018-04-24','crop.jpeg','XXXXXXXXXXXXXXXXXX','fsdfdsfds',0,'published'),(6,1,'Lorem Ipsum','me','2018-04-24','Screenshot from 2018-02-10 19-47-05.png','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc viverra est eget ex lacinia, nec sollicitudin libero venenatis. Vestibulum vitae aliquet augue. Aenean scelerisque quis urna id porta. Nullam lacus felis, pulvinar eu sem sed, luctus feugiat arcu. Aenean et porttitor nunc. Vestibulum tincidunt enim viverra sem porttitor imperdiet. Aenean nec enim id sem elementum viverra. Ut quis feugiat ante. Suspendisse molestie tellus non lectus dignissim, in porttitor ex venenatis. Nullam tristique mi et ligula laoreet, sit amet euismod ligula porttitor.\r\n\r\nInteger rhoncus nunc scelerisque leo sagittis, eu elementum massa tempus. Donec dignissim felis eget risus interdum pharetra. Nulla sagittis nisi at aliquam fringilla. Phasellus quis massa magna. Curabitur pretium laoreet tortor non congue. Proin convallis diam ac libero gravida maximus. Vestibulum accumsan metus eget lectus varius semper. Aenean sed ante in justo interdum porttitor id nec nulla. Cras lacinia nunc in congue dapibus. Morbi non ligula tincidunt, ornare lacus vel, porttitor velit. In faucibus ante sed magna finibus, et efficitur lectus imperdiet. Aenean ut urna vitae diam vestibulum eleifend et nec quam. Donec vitae arcu vel odio lobortis volutpat a et leo. Donec consectetur elit vitae eros elementum semper. Suspendisse nec cursus ipsum.\r\n\r\nQuisque sed pellentesque lectus, a convallis sapien. Ut vel risus pellentesque mauris eleifend efficitur. Donec mollis gravida elit, nec consectetur mi fringilla sed. Phasellus scelerisque, lectus in laoreet semper, turpis lacus sagittis ligula, sit amet varius lorem nisl at metus. Sed luctus sem sed urna lobortis, sit amet rhoncus diam congue. Proin at lectus non ante aliquet placerat sit amet non lectus. Proin sed nunc ligula. In at purus et felis ullamcorper semper. Phasellus id ultrices orci, sed faucibus mauris. Quisque facilisis libero urna, ac maximus arcu facilisis a.','lorem',0,'published'),(7,1,'Next New post','Pepito','2018-04-24','Screenshot from 2018-02-20 18-37-30.png','Expenses as material breeding insisted building to in. Continual so distrusts pronounce by unwilling listening. Thing do taste on we manor. Him had wound use found hoped. Of distrusts immediate enjoyment curiosity do. Marianne numerous saw thoughts the humoured. \r\nHe share of first to worse. Weddings and any opinions suitable smallest nay. My he houses or months settle remove ladies appear. Engrossed suffering supposing he recommend do eagerness. Commanded no of depending extremity recommend attention tolerably. Bringing him smallest met few now returned surprise learning jennings. Objection delivered eagerness he exquisite at do in. Warmly up he nearer mr merely me. \r\nDoubtful two bed way pleasure confined followed. Shew up ye away no eyes life or were this. Perfectly did suspicion daughters but his intention. Started on society an brought it explain. Position two saw greatest stronger old. Pianoforte if at simplicity do estimating. \r\nAre own design entire former get should. Advantages boisterous day excellence boy. Out between our two waiting wishing. Pursuit he he garrets greater towards amiable so placing. Nothing off how norland delight. Abode shy shade she hours forth its use. Up whole of fancy ye quiet do. Justice fortune no to is if winding morning forming. \r\nAt as in understood an remarkably solicitude. Mean them very seen she she. Use totally written the observe pressed justice. Instantly cordially far intention recommend estimable yet her his. Ladies stairs enough esteem add fat all enable. Needed its design number winter see. Oh be me sure wise sons no. Piqued ye of am spirit regret. Stimulated discretion impossible admiration in particular conviction up. \r\nMind what no by kept. Celebrated no he decisively thoroughly. Our asked sex point her she seems. New plenty she horses parish design you. Stuff sight equal of my woody. Him children bringing goodness suitable she entirely put far daughter. \r\nWindows talking painted pasture yet its express parties use. Sure last upon he same as knew next. Of believed or diverted no rejoiced. End friendship sufficient assistance can prosperous met. As game he show it park do. Was has unknown few certain ten promise. No finished my an likewise cheerful packages we. For assurance concluded son something depending discourse see led collected. Packages oh no denoting my advanced humoured. Pressed be so thought natural. \r\nPerformed suspicion in certainty so frankness by attention pretended. Newspaper or in tolerably education enjoyment. Extremity excellent certainty discourse sincerity no he so resembled. Joy house worse arise total boy but. Elderly up chicken do at feeling is. Like seen drew no make fond at on rent. Behaviour extremely her explained situation yet september gentleman are who. Is thought or pointed hearing he. \r\nTalking chamber as shewing an it minutes. Trees fully of blind do. Exquisite favourite at do extensive listening. Improve up musical welcome he. Gay attended vicinity prepared now diverted. Esteems it ye sending reached as. Longer lively her design settle tastes advice mrs off who. \r\nLose eyes get fat shew. Winter can indeed letter oppose way change tended now. So is improve my charmed picture exposed adapted demands. Received had end produced prepared diverted strictly off man branched. Known ye money so large decay voice there to. Preserved be mr cordially incommode as an. He doors quick child an point at. Had share vexed front least style off why him. ','beauty',2,'published');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(3) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_firstname` varchar(255) NOT NULL,
  `user_lastname` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_image` text NOT NULL,
  `user_role` varchar(255) NOT NULL,
  `randSalt` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'rico','123','Rico','Suave','suave@gmail.com','','admin',''),(2,'test','test','test','test','test@test.com','','subscriber',''),(4,'Margerita','Margerita','Margerita','Margerita','Margerita@Margerita.com','','subscriber',''),(5,'Sandra','Margerita','Paco','Sandra','Rocky@Margerita.com','','admin','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-02  3:00:01
